// Exercise 3:

window.addEventListener("DOMContentLoaded", function () {
    document.getElementsByTagName("button")[0].addEventListener("click", highlightWords);
});


function highlightWords() {

    const oldElement = document.getElementsByTagName("p")[0];
    const newText = document.createElement('p');


    const wordsAndPontuation = oldElement.textContent.match(/([^.,!?;:()"' ]|'\S)+|[.,!?;:()"' ]+/g);


    for (const word of wordsAndPontuation) {
        if (word.length >= 8) {
            const wordSpan = document.createElement('span');
            wordSpan.classList.add('pink');
            wordSpan.textContent = word;
            newText.append(wordSpan);
        } else if (word.length === 6) {
            const wordSpan = document.createElement('span');
            wordSpan.classList.add('purple');
            wordSpan.textContent = word;
            newText.append(wordSpan);
        } else if (word.length === 5 || word.length === 4) {
            const wordSpan = document.createElement('span');
            wordSpan.classList.add('blue');
            wordSpan.textContent = word;
            newText.append(wordSpan);
        } else {
            const textNode = document.createTextNode(word);
            newText.append(textNode);
        }
    }

    document.getElementsByTagName('body')[0].replaceChild(newText, oldElement);
}