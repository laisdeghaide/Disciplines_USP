// Exercise 2:

const colors = ["brown", "green", "purple", "yellow", "pink", "blue", "black"];

// a.
window.addEventListener("DOMContentLoaded", function () {
    changeHeading();
    addMouseOverListeners();
    startRandomColorChanger();
});


// b. 
function changeHeading() {
    let heading = document.getElementById("change_heading");
    heading.innerHTML = "Select your color!";
}


// c.

function changeSelectedColor(event) {
    document.getElementsByClassName("selected")[0].innerText = event.srcElement.className.charAt(0).toLocaleUpperCase() + event.srcElement.className.slice(1);
};

function addMouseOverListeners() {
    let box = document.getElementsByTagName("section")[0];
    let divs = box.childNodes;

    divs.forEach(color => {
        color.addEventListener("mouseover", changeSelectedColor);
    })
}


// d.

function getRandom(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function startRandomColorChanger() {

    let random = document.createElement("div");
    random.id = "random";
    random.addEventListener("mouseover", changeSelectedColor);
    document.getElementsByTagName("section")[0].appendChild(random);
    random.className = colors[Math.floor(getRandom(1, colors.length)) - 1];
    setInterval(function () {
        let box = document.getElementById("random");
        let curr = box.className;
        let color = colors[Math.floor(getRandom(1, colors.length)) - 1];

        while (curr == color) {
            color = colors[Math.floor(getRandom(1, colors.length)) - 1];
        }

        box.className = color;

    }, 500);
}