for (let i = 0; i <= 15; i++) {
    (i % 2 == 0) ? console.log(i + " is even") : console.log(i + " is odd")
}

