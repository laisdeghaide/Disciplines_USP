//Laís Saloum Deghaide, nUSP: 11369767
//Thiago Henrique dos Santos Cardoso, nUSP: 11796594

#ifndef FUNCAO_FORNECIDA_H
#define FUNCAO_FORNECIDA_H

//Funcoes Passadas
void binarioNaTela(char *nomeArquivoBinario);
void scan_quote_string(char *str);
int convertePrefixo(char* str);

#endif