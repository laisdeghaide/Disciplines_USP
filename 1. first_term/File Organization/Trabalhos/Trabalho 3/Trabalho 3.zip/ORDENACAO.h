//Laís Saloum Deghaide, nUSP: 11369767
//Thiago Henrique dos Santos Cardoso, nUSP: 11796594

#ifndef ORDENACAO_H
#define ORDENACAO_H

#include "constants.h"
#include "funcoesLeitura.h"
#include "funcoesEscrita.h"
#include "funcoesArvB.h"
#include "arvB.h"
#include "funcoesFornecidas.h"
#include "funcoesOrdenacao.h"

//Funcao pedida responsável pelo sort
void ORDENACAO(int c);

#endif
