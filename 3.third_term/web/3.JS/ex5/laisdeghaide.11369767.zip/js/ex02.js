"use strict";

function checkUSPDomain(domain) {
  const regex = /((https?:\/\/)?(.+?\.)?usp\.br(\/[A-Za-z0-9\-\._~:\/\?#\[\]@!$&'\(\)\*\+,;\=]*)?)/;
  return regex.test(domain);
}

const domain = prompt("Digite um domínio USP válido: ");
if (checkUSPDomain(domain)) {
  alert("Domínio válido!");
} else {
  alert("Domínio inválido!");
}
