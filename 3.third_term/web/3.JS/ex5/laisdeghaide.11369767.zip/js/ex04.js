class CircularBuffer {
  #size;

  constructor(size) {
    this.#size = size;
    this.buffer = [];
  }
  put(value) {
    if (this.buffer.length < this.#size) {
      this.buffer.push(value);
    }
    else {
      this.buffer.shift();
      this.buffer.push(value);
    }
    return this;
  }
  pop() {
    if (this.buffer.length > 0) {
      return this.buffer.shift();
    }
    throw new Error("Circular Buffer is empty");
  }

  get size() {
    return this.#size;
  }

  get free() {
    return this.#size - this.buffer.length;
  }

  toString() {
    let str = "";
    for (let i = 0; i < this.buffer.length; i++) {
      str += '[';

      if (typeof this.buffer[i] === 'string') {
        str += "'";
      }

      str += this.buffer[i];

      if (typeof this.buffer[i] === 'string') {
        str += "'";
      }

      str += ']';

      if (i !== this.buffer.length - 1) {
        str += ", ";
      }
    }
    return str;
  }

}

const buffer = new CircularBuffer(5);
console.log(buffer.size);  // 5
try { buffer.size = 9; } catch (e) { } // Error
buffer.put(8).put('a').put(3);
console.log(`${buffer}`); // Buffer = [8], ['a'], [3]
console.log(buffer.pop() + ' free: ' + buffer.free); // 8 free: 3
console.log(`${buffer}`); // Buffer = ['a'], [3]
buffer.put(4).put(5).put(6).put(7);
console.log(`${buffer}`); // Buffer = [3], [4], [5], [6], [7]
buffer.pop(); buffer.pop(); buffer.pop();
buffer.pop(); buffer.pop();
buffer.pop(); // Error: Circular buffer is empty.
