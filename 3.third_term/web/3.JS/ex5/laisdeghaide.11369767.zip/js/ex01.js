"use strict";

class BankAccount {
  #balance = 0;
  #client;

  constructor(name, address) {
    this.balance = 0;
    this.#client = new Client(name, address);
  }

  get balance() {
    return this.#balance;
  }

  set balance(x) {
    this.#balance = x;
  }

  get client() {
    return this.#client;
  }

  interest(x) {
    this.balance = this.balance * (1 + (x / 100));
  }

  withdraw(amount) {
    if (amount > this.balance) {
      alert("Fundos Insuficientes!");
      return;
    }
    this.balance = this.balance - amount;
  }

}

class Client {
  #name;
  #address;

  constructor(name, address) {
    this.name = name;
    this.address = address;
  }

  get name() {
    return this.#name;
  }

  set name(x) {
    this.#name = x;
  }

  get address() {
    return this.#address;
  }

  set address(x) {
    this.#address = x;
  }
}

// a.
const name = prompt("Qual seu nome?");
const address = prompt("Qual seu endereço?");

const account = new BankAccount(name, address);

// b.

const amount = prompt("Qual o valor a ser depositado?");
account.balance = amount;
alert(`Olá ${account.client.name}, seu saldo é de R$ ${account.balance}`);

// c.

const interest = prompt("Qual a porcentagem de juros a ser depositado?");
account.interest(interest);
alert(`Olá ${account.client.name}, seu saldo é de R$ ${account.balance}`);

// d.

const withdrawAmount = prompt("Qual o valor a ser sacado?");
account.withdraw(withdrawAmount);
alert(`Olá ${account.client.name}, seu saldo é de R$ ${account.balance}`);


