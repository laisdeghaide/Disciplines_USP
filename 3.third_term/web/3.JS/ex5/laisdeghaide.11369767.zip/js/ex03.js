"use strict";

class Shape {
  _type;
  _perimeter;

  get type() {
    return this._type;
  }

  get perimeter() {
    return this._perimeter;
  }

}

class Triangle extends Shape {
  #a;
  #b;
  #c;

  constructor(a, b, c) {
    super();
    this._type = "Triangle";
    this.#a = a;
    this.#b = b;
    this.#c = c;
  }

  perimeter() {
    return this.#a + this.#b + this.#c;
  }

}

class Square extends Shape {
  #side;

  constructor(a) {
    super();
    this._type = "Square";
    this.#side = a;
  }

  perimeter() {
    return this.#side * 4;
  }

}


const t = new Triangle(1, 2, 3);
console.log(t.type); // Triangle
console.log(t.perimeter); // 6
const q = new Square(2);
console.log(q.type); // Square
console.log(q.perimeter); // 8
q.perimeter = 9; // Error
